package com.example.ihpgroup;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.PopupMenu;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class JadwalKelas2Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_jadwal_kelas2);

        ImageView back = findViewById(R.id.back);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(JadwalKelas2Activity.this, JadwalkanActivity.class));
            }
        });

        ImageView menuIcon = findViewById(R.id.menu);
        menuIcon.setOnClickListener(v -> {
            PopupMenu popupMenu = new PopupMenu(JadwalKelas2Activity.this, v);
            popupMenu.getMenu().add("Kelas Teori");
            popupMenu.getMenu().add("Kelas Lab");

            popupMenu.setOnMenuItemClickListener(item -> {
                String selectedItem = item.getTitle().toString();
                Toast.makeText(JadwalKelas2Activity.this, "" + selectedItem, Toast.LENGTH_SHORT).show();
                return true;
            });

            popupMenu.show();
        });

    }
}