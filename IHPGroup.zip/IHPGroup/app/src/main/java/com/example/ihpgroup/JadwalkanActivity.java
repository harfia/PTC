package com.example.ihpgroup;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class JadwalkanActivity extends AppCompatActivity {

    private EditText namaEditText, nidnEditText;
    private Spinner matkulSpinner, ruanganSpinner, waktuSpinner;
    private Button bookingButton;

    // Firebase Database reference
    private DatabaseReference database;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_jadwalkan); // Make sure this is the correct layout

        // Initialize Firebase Database reference
        database = FirebaseDatabase.getInstance().getReference();

        // Initialize UI components
        namaEditText = findViewById(R.id.nama);
        nidnEditText = findViewById(R.id.nidn);
        matkulSpinner = findViewById(R.id.matkul);
        ruanganSpinner = findViewById(R.id.ruangan);
        waktuSpinner = findViewById(R.id.waktu);
        bookingButton = findViewById(R.id.booking_hal);

        // Spinner data
        String[] matkulItems = {"Pilih Mata Kuliah", "Mobile", "Big Data", "Etika Profesi", "Machine Learning", "IoTKA"};
        String[] ruanganItems = {"Pilih Ruangan", "R.Macca 101", "R.Makkawaru 102", "R.Mareso 103"};
        String[] waktuItems = {"Pilih Waktu", "07.30 - 09.00", "09.05 - 10.35", "10.40 - 12.00"};

        // Initialize spinners
        ArrayAdapter<String> matkulAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, matkulItems);
        matkulAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        matkulSpinner.setAdapter(matkulAdapter);

        ArrayAdapter<String> ruanganAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, ruanganItems);
        ruanganAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        ruanganSpinner.setAdapter(ruanganAdapter);

        ArrayAdapter<String> waktuAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, waktuItems);
        waktuAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        waktuSpinner.setAdapter(waktuAdapter);

        // Set up button click listener
        bookingButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Get data from the UI elements
                String nama = namaEditText.getText().toString().trim();
                String nidn = nidnEditText.getText().toString().trim();
                String matkul = matkulSpinner.getSelectedItem().toString();
                String ruangan = ruanganSpinner.getSelectedItem().toString();
                String waktu = waktuSpinner.getSelectedItem().toString();

                // Validate input
                if (nama.isEmpty() || nidn.isEmpty()) {
                    Toast.makeText(JadwalkanActivity.this, "Nama dan NIDN harus diisi", Toast.LENGTH_SHORT).show();
                    return;
                }

                // Generate a unique ID for each booking entry
                String bookingId = database.push().getKey();

                // Create a Booking object
                Booking booking = new Booking(nama, nidn, matkul, ruangan, waktu);

                // Save data to Firebase Realtime Database
                if (bookingId != null) {
                    database.child("bookings").child(bookingId).setValue(booking)
                            .addOnSuccessListener(aVoid -> {
                                Toast.makeText(JadwalkanActivity.this, "Booking berhasil", Toast.LENGTH_SHORT).show();
                                // Optionally, clear the form
                                namaEditText.setText("");
                                nidnEditText.setText("");
                                matkulSpinner.setSelection(0);
                                ruanganSpinner.setSelection(0);
                                waktuSpinner.setSelection(0);
                            })
                            .addOnFailureListener(e -> {
                                Toast.makeText(JadwalkanActivity.this, "Gagal menyimpan data", Toast.LENGTH_SHORT).show();
                            });
                }
            }
        });
    }

    // Booking model class to hold data
    public static class Booking {
        public String nama;
        public String nidn;
        public String matkul;
        public String ruangan;
        public String waktu;

        // Default constructor required for Firebase
        public Booking() {}

        // Constructor
        public Booking(String nama, String nidn, String matkul, String ruangan, String waktu) {
            this.nama = nama;
            this.nidn = nidn;
            this.matkul = matkul;
            this.ruangan = ruangan;
            this.waktu = waktu;
        }
    }
}
