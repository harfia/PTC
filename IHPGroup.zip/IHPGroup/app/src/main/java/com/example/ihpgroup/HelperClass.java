package com.example.ihpgroup;

public class HelperClass {
    private String nama;
    private String nidn;
    private String matkul;
    private String ruangan;
    private String waktu;

    public HelperClass(String nama, String nidn, String matkul, String ruangan, String waktu) {
        this.nama = nama;
        this.nidn = nidn;
        this.matkul = matkul;
        this.ruangan = ruangan;
        this.waktu = waktu;
    }

    // Getter and Setter methods
    public String getNama() {
        return nama;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public String getNidn() {
        return nidn;
    }

    public void setNidn(String nidn) {
        this.nidn = nidn;
    }

    public String getMatkul() {
        return matkul;
    }

    public void setMatkul(String matkul) {
        this.matkul = matkul;
    }

    public String getRuangan() {
        return ruangan;
    }

    public void setRuangan(String ruangan) {
        this.ruangan = ruangan;
    }

    public String getWaktu() {
        return waktu;
    }

    public void setWaktu(String waktu) {
        this.waktu = waktu;
    }
}
