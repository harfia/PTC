package com.example.ihpgroup;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;

public class RosterActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_roster);

        Button senin = findViewById(R.id.btn_senin);
        senin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Navigasi ke JadwalActivity
                startActivity(new Intent(RosterActivity.this, com.example.ihpgroup.JadwalActivity.class));
            }
        });

        Button selasa = findViewById(R.id.btn_selasa);
        selasa.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Navigasi ke JadwalActivity
                startActivity(new Intent(RosterActivity.this, com.example.ihpgroup.Jadwal2Activity.class));
            }
        });
        Button rabu = findViewById(R.id.btn_rabu);
        rabu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Navigasi ke JadwalActivity
                startActivity(new Intent(RosterActivity.this, com.example.ihpgroup.JadwalActivity.class));
            }
        });
        Button kamis = findViewById(R.id.btn_kamis);
        kamis.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Navigasi ke JadwalActivity
                startActivity(new Intent(RosterActivity.this, com.example.ihpgroup.JadwalActivity.class));
            }
        });
        Button jumat = findViewById(R.id.btn_jumat);
        jumat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Navigasi ke JadwalActivity
                startActivity(new Intent(RosterActivity.this, com.example.ihpgroup.JadwalActivity.class));
            }
        });

        ImageView person = findViewById(R.id.person);
        person.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(RosterActivity.this, ProfilActivity.class));
            }
        });

        ImageView calendar = findViewById(R.id.calendar);
        calendar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(RosterActivity.this, JadwalKelasActivity.class));
            }
        });
    }
}
