package com.example.ihpgroup;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.PopupMenu;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class JadwalKelasActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_jadwal_kelas);

        ImageView back = findViewById(R.id.back);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(JadwalKelasActivity.this, JadwalkanActivity.class));
            }
        });

        ImageView menuIcon = findViewById(R.id.menu);
        menuIcon.setOnClickListener(v -> {
            PopupMenu popupMenu = new PopupMenu(JadwalKelasActivity.this, v);
            popupMenu.getMenu().add("Kelas Teori");
            popupMenu.getMenu().add("Kelas Lab");

            popupMenu.setOnMenuItemClickListener(item -> {
                String selectedItem = item.getTitle().toString();
                Toast.makeText(JadwalKelasActivity.this, "Selected: " + selectedItem, Toast.LENGTH_SHORT).show();

                // Pindah ke aktivitas yang sesuai berdasarkan pilihan
                if (selectedItem.equals("Kelas Teori")) {
                    startActivity(new Intent(JadwalKelasActivity.this, JadwalKelasActivity.class)); // Kelas Teori
                } else if (selectedItem.equals("Kelas Lab")) {
                    startActivity(new Intent(JadwalKelasActivity.this, JadwalKelas2Activity.class)); // Kelas Lab
                }
                return true;
            });

            popupMenu.show();
        });

    }
}