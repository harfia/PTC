package com.example.ihpgroup;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.PopupMenu;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class Jadwal3Activity extends AppCompatActivity {

    private TextView seninTextView, waktuMulaiTextView, waktuSelesaiTextView, kelasTextView, mataKuliahTextView, aksiTextView;
    private TextView waktuMulaiTextView2, waktuSelesaiTextView2, kelasTextView2, mataKuliahTextView2, aksiTextView2;
    private DatabaseReference database;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_jadwal3);

        // Inisialisasi referensi Firebase Database
        database = FirebaseDatabase.getInstance().getReference();

        // Inisialisasi TextViews
        seninTextView = findViewById(R.id.Rabu);
        waktuMulaiTextView = findViewById(R.id.header_waktu);
        waktuSelesaiTextView = findViewById(R.id.header_waktuselesai);
        kelasTextView = findViewById(R.id.header_kelas);
        mataKuliahTextView = findViewById(R.id.header_matakuliah);
        aksiTextView = findViewById(R.id.header_aksi);

        // Additional Views (for second set of data)
        waktuMulaiTextView2 = findViewById(R.id.header_waktu2);
        waktuSelesaiTextView2 = findViewById(R.id.header_waktuselesai2);
        kelasTextView2 = findViewById(R.id.header_kelas2);
        mataKuliahTextView2 = findViewById(R.id.header_matakuliah2);
        aksiTextView2 = findViewById(R.id.header_aksi2);

        // Ambil data dari Firebase
        fetchDataFromFirebase();

        // Menu Button
        ImageView menuIcon = findViewById(R.id.menu);
        menuIcon.setOnClickListener(v -> {
            PopupMenu popupMenu = new PopupMenu(Jadwal3Activity.this, v);
            popupMenu.getMenu().add("Kelas Teori");
            popupMenu.getMenu().add("Kelas Lab");

            popupMenu.setOnMenuItemClickListener(item -> {
                String selectedItem = item.getTitle().toString();
                Toast.makeText(Jadwal3Activity.this, "" + selectedItem, Toast.LENGTH_SHORT).show();
                return true;
            });

            popupMenu.show();
        });

        // Edit Button
        ImageView editButton = findViewById(R.id.icon_edit);
        editButton.setOnClickListener(v -> {
            // Pindah ke JadwalkanActivity (Layar Edit)
            Intent intent = new Intent(Jadwal3Activity.this, JadwalkanActivity.class);
            startActivity(intent);
        });

        // Delete Button
        ImageView deleteButton = findViewById(R.id.icon_delete);
        deleteButton.setOnClickListener(v -> {
            ImageView imageView = (ImageView) v;  // Casting ke ImageView
            imageView.setAlpha(0.5f);
            imageView.setColorFilter(getResources().getColor(android.R.color.darker_gray));
            Toast.makeText(Jadwal3Activity.this, "Kelas Anda Batalkan", Toast.LENGTH_SHORT).show();
        });

        // Back Button
        ImageView back = findViewById(R.id.back);
        back.setOnClickListener(view -> {
            // Pindah ke RosterActivity
            Intent intent = new Intent(Jadwal3Activity.this, RosterActivity.class);
            startActivity(intent);
        });
    }

    private void fetchDataFromFirebase() {
        // Ambil data dari Firebase Database dan perbarui UI
        database.child("bookings").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                int index = 0; // To keep track of the number of bookings
                // Iterasi melalui setiap booking dan tampilkan data
                for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                    Booking booking = snapshot.getValue(Booking.class);

                    if (booking != null) {
                        // Update data untuk setiap booking
                        if (index == 0) {
                            // Set the first booking data
                            seninTextView.setText("Senin");
                            waktuMulaiTextView.setText(booking.waktu); // Menampilkan waktu mulai
                            waktuSelesaiTextView.setText(booking.waktu); // Sesuaikan dengan data yang dimiliki
                            kelasTextView.setText(booking.ruangan);
                            mataKuliahTextView.setText(booking.matkul);
                            aksiTextView.setText("Edit | Hapus");
                        } else if (index == 1) {
                            // Set the second booking data
                            waktuMulaiTextView2.setText(booking.waktu); // Menampilkan waktu mulai
                            waktuSelesaiTextView2.setText(booking.waktu); // Sesuaikan dengan data yang dimiliki
                            kelasTextView2.setText(booking.ruangan);
                            mataKuliahTextView2.setText(booking.matkul);
                            aksiTextView2.setText("Edit | Hapus");
                        }
                        index++;
                    }
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                // Menangani error database
                Toast.makeText(Jadwal3Activity.this, "Gagal memuat data.", Toast.LENGTH_SHORT).show();
            }
        });
    }

    // Kelas model Booking (sama seperti di JadwalkanActivity)
    public static class Booking {
        public String nama;
        public String nidn;
        public String matkul;
        public String ruangan;
        public String waktu;

        // Konstruktor default untuk Firebase
        public Booking() {}

        // Konstruktor
        public Booking(String nama, String nidn, String matkul, String ruangan, String waktu) {
            this.nama = nama;
            this.nidn = nidn;
            this.matkul = matkul;
            this.ruangan = ruangan;
            this.waktu = waktu;
        }
    }
}
