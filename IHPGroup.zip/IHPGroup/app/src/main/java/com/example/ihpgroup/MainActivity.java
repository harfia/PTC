package com.example.ihpgroup;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
public class MainActivity extends AppCompatActivity {

    private EditText emailEditText, passwordEditText;
    private Button btnLogin;
    private DatabaseReference mDatabase;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Inisialisasi Firebase Realtime Database
        mDatabase = FirebaseDatabase.getInstance().getReference();

        // Inisialisasi elemen UI
        emailEditText = findViewById(R.id.email);
        passwordEditText = findViewById(R.id.password);
        btnLogin = findViewById(R.id.btn_login);

        // Menangani klik tombol login
        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String email = emailEditText.getText().toString().trim();
                String password = passwordEditText.getText().toString().trim();

                if (email.isEmpty() || password.isEmpty()) {
                    Toast.makeText(MainActivity.this, "Silakan isi kedua kolom", Toast.LENGTH_SHORT).show();
                    return;
                }

                // Simpan data email dan password ke Firebase Realtime Database
                saveUserData(email, password);

                // Tampilkan pesan sukses dan lanjut ke activity berikutnya
                Toast.makeText(MainActivity.this, "Data pengguna berhasil disimpan", Toast.LENGTH_SHORT).show();

                // Pindah ke activity berikutnya (misalnya WelcomeActivity)
                startActivity(new Intent(MainActivity.this, WelcomeActivity.class));
                finish(); // Menutup halaman login
            }
        });
    }

    // Metode untuk menyimpan data pengguna
    private void saveUserData(String email, String password) {
        // Membuat objek User dengan email dan password
        String userId = email.replace("hurul", "22"); // Firebase tidak bisa menggunakan titik (.) dalam key
        User user = new User(email, password);

        // Menyimpan data pengguna ke Firebase Realtime Database di bawah node "users"
        mDatabase.child("users").child(userId).setValue(user);
    }

    // Kelas User untuk mewakili data pengguna
    public static class User {
        public String email;
        public String password;

        public User(String email, String password) {
            this.email = email;
            this.password = password;
        }
    }
}
